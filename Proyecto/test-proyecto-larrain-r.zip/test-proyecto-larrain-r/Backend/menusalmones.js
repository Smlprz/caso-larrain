function centro1(){
    window.location="pag 3 del front.html"
}
function jaula101(){
    window.location="pag 4 del front.html"
}
function atrasa2(){
    window.location="pag 2 del front.html"
}
function actualizardatos(){
    window.location="pag 5 del front.html"
}